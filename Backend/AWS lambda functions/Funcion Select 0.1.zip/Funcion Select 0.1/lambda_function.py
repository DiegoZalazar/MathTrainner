import os
import json
import pymysql


# Configura la conexión a la base de datos
conn = pymysql.connect(
        host = os.environ['HOST'],
        user = os.environ['USER'],
        passwd = os.environ['PASSWORD'],
        db = os.environ['DB'],
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )
# Obtén la consulta SQL de las variables de entorno
query = os.environ['QUERY']

def lambda_handler(event, context):
    # Ejecuta la consulta SQL y obtén los resultados
    with conn.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchall()
    # Devuelve los resultados como JSON
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }




